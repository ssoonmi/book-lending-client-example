# Part II

Today, we will be learning how to do user authentication and mutations in the frontend with Apollo Client.

Please use the Part I that you worked on yesterday for this project or clone/download this repo.

## Authentication on the Server

Authentication is already set up in the server. If you need to familiarize yourself with how to set up authentication in the server, take a look at the following server files: 

- index.js - initializing passport and connecting the passport middleware to graphql
- config/passport.js - configuring passport to get the token from the `authorization` header and finding a user by the id
- middlewares/index.js `passportAuthenticate` function - if there is a user from the token, then put the user on the request (which will be the context argument to the GraphQL resolvers)
- schema/types/User.js - `login` mutation that returns a `UserCredentials` type with a `token` and a `loggedIn` field
- models/User.js - `login` function defined on the `User` model that will put `token` and `loggedIn` properties on the return of the mutation

## Authentication on the Client

Authentication on the client will be validated through the token stored on `localStorage`, which is a way for data to be persisted on the client, similar to how cookies persist through refreshes.

Let's set our `authorization` header to the `token` in our `localStorage`. Head over to the `src/graphql/client.js` file and add the `authorization` key to our `headers` in our `httpLink` to `localStorage.getItem('token')`.

```javascript
// src/graphql/client.js
const httpLink = new HttpLink({
  uri: 'http://localhost:5000/graphql',
  headers: {
    authorization: localStorage.getItem('token')
  }
});
```

Let's test this out. First we need to set our `token` to our `localStorage`. In GraphQL Playground, `login` with the demo user who has a `username` of `"demo"` and `password` of `"password"`. You should return the `token` from this query. In the Chrome DevTools console, write `localStorage.setItem('token', token)` where `token` is the `token` you got back from Playground.

Next, we need to use our `client` to query our server to see if the `authorization` header was set properly. If you head over to Playground again, you'll see a `me` query in the schema. Let's use this query to return information about the current user using the `token`. 

Right after the definition of our `client`, let's do:

```javascript
// src/graphql/client.js after defining the client
client
  .query({
    query: gql`
      query CurrentUser {
        me {
          _id
          username
        }
      }
    `
  })
  .then(result => console.log(result));
```

Make sure to `import gql from 'graphql-tag'` at the top of the file. 

This is querying our server for the current user with the `headers` defined in our `httpLink`. 

Refresh the page and take a look at what was logged in the console. You should see an object with `data` and `data.me` including the information about the demo user.

If we clear the token, `localStorage.removeItem('token')` and refresh the page, then you should see an object logged with `data` and `data.me` with the value of `null`. **Remove or comment out the query after finishing tests.**

Awesome! Our server will now know if there is a current user from the `token` that we defined on our `authorization` header. But how does our client know if there is a user that is logged in? In `Redux`, we had a slice of state called `session` that stored the `id` of our current user and identified if there was an authenticated user. Similar to that, we will use the `cache` in Apollo Client to identify if there is a logged in user.

When our app loads for the first time, we need to tell the `cache` if there is a user logged in or not. This will be determined by the presence of our `token` in the `localStorage`.

One way of doing this, is to define **local `typeDefs` and `resolvers`** which exist **only on the client**, not on the server. We can create a client-only `Query` which will tell us if there is a user logged in or not based on the `token` in the `localStorage`.

To make these local `typeDefs` and `resolvers`, create a file called `resolvers.js` in `src/graphql` folder. 

We want to `extend` the `Query` `type` to include a `isLoggedIn` field that will always resolve to a `Boolean` value. We are then going to create a `resolver` function on the `Query` type called  `isLoggedIn` that will return `true` if there is a `token`, and `false` if there isn't.

```javascript
// src/graphql/resolvers.js
import gql from 'graphql-tag';

export const typeDefs = gql`
  extend type Query {
    isLoggedIn: Boolean!
  }
`;

export const resolvers = {
  // for data that only exists in the frontend
  Query: {
    isLoggedIn: () => {
      // console.log('isLoggedIn resolver called') // comment this in to see when this resolver function is called
      return !!localStorage.getItem("token")
    }
  }
};
```

Export the `typeDefs` and `resolvers`

Now we have to connect the `typeDefs` and `resolvers` to the `client`. Import them into the `src/graphql/client.js` file. Attach them to the `client` as keys to the options object when defining the `client`: 

```javascript
// src/graphql/client.js client definition
const client = new ApolloClient({
  cache,
  link: ApolloLink.from(links),
  typeDefs,
  resolvers
});
```

This isn't enough for the client to know whether or not we have a real authenticated user. Our `token` could be expired or the `user` could not exist anymore. So, we need to tell our client to query for the current user data if there is a `token`. If the query returns a valid user, then we are fine, but if it doesn't, then we have to either set the `isLoggedIn` boolean in our `cache` to `false` or reset the `cache`. 

Resetting the `cache` has pros and cons. When resetting the `cache`, any user specific data will be erased upon log out. But, you will lose all your `cache`d data. Let's reset the `cache` for now, and you can choose if it's resetting the store is the best decision for your app for yourself later.

After the client definition, we will be using the `me` query to return information about our current user.

```javascript
// src/graphql/client.js after defining client
const CURRENT_USER = gql`
  query CurrentUser {
    me {
      _id
      username
    }
  }
`;

// wait to see if there is a current user
if (localStorage.getItem('token')) {
  client
    .query({ query: CURRENT_USER })
    .then(({ data }) => {
      // console.log(data); // comment this in to see what data returns
      // if there is no data or data.me is null, then reset the cache
      if (!data || !data.me) client.resetStore();
    });
}
```

If there is no `data` or `data.me` is null, then reset the `cache`. 

We should also remove the invalid `token` from our `localStorage` when the client is reset. We can define what our cache should do when our `cache` is reset using, `client.onResetStore`. This takes in a callback function that will be called whenever our `cache` resets.

```javascript
// src/graphql/client.js
// call resetStore whenever logging out
client.onResetStore(() => {
  localStorage.clear();
});

if (localStorage.getItem('token')) {
  //...
}
```

Hang on. I forgot to mention that `client.query` is an asynchronous function. This means that our app could start to render things without our app knowing if there is a valid user or not. Let's wait for this `client.query` to run by `await`ing this and making the `createClient` function `async`. 

We need to refactor the entry file a bit now. Our `createClient` doesn't return the `client` when called anymore. Since our `createClient` function is `async`, we need to wait for the `createClient` to run. The callback to a `.then` function defined on `createClient()` should take in the return value of the `createClient` function, which is the `client`.

```javascript
// src/index.js
createClient().then(client => {
  ReactDOM.render(
    <ApolloProvider client={client}>
      <App />
    </ApolloProvider>,
    document.getElementById("root")
  );
});
```

Now we should be done with setting up our `client` for authentication for now! But how do we test this? Let's put the `client` and `gql` from `graphql-tag` on the window, but only do this when we are in development mode.

```javascript
if (process.env.NODE_ENV === 'development') {
  window.client = client;
  window.gql = gql;
}
```

Next, let's comment in the `console.log`'s in the `isLoggedIn` resolver function and in the `.then` to the `CURRENT_USER` `query` in `client.js`.

Set the `token` on the `localStorage` to the `token` from earlier and refresh the page. You should see the current user's information printed in the console.

Let's query our `client` for `isLoggedIn`. When we call this query, we have to make sure we add an `@client` keyword after `isLoggedIn`. This will tell the `client` to only ask for the information in our `cache` rather than our server. The query should look like this:

```graphql
query IsLoggedIn {
  isLoggedIn @client
}
```

Use the `client` on the window to `query` for `isLoggedIn`:

```javascript
// run in our Chrome DevTools console
client.query({
  query: gql`
    query isLoggedIn {
      isLoggedIn @client
    }
  `
}).then((data) => console.log(data));
```

We should see `"isLoggedIn resolver called"` logged in our console as well as what the `query` returned, which should have `isLoggedIn: true`. If you run the same query, you don't get `"isLoggedIn resolver called"` logged again. Can you guess why?

The `isLoggedIn` is not stored in the `cache` the first time that the `query` is made, and the `client` will ask for the information from the local `resolvers`. But after the `query` is first called, `isLoggedIn` is stored in the `cache` and can be fetched from there instead of going to the local `resolvers`.

Let's simulate logging out by calling `client.resetStore()` and then running the query again. This will clear our `cache` so the `isLoggedIn` resolver has to be called again to fetch the information asked from the query.

## Current User Profile

Let's create a `UserProfile` which will be a `ProtectedRoute` and will render the list of books that the current user has borrowed and the `LogOutButton`.

We will be using the `me` query to gain information about the current user and their borrowed `books`.

The `CURRENT_USER` query that we used in our `createClient` function at `src/graphql/client.js` can be reused, so let's move that query to our queries in `src/graphql/queries.js`. Make sure to import it in the `client.js` file after you move it.

We need to refactor that query so it returns all the borrowed `books` for the current user, not just the `_id` and the `username`.

```javascript
// src/graphql/queries.js
export const CURRENT_USER = gql`
  query CurrentUser {
    me {
      _id
      username
      books {
        _id
        title
      }
    }
  }
`;
```

Now, create a `UserProfile` page in our `src/pages` and create a route for it in `App.js` at `/me`.

Your `UserProfile` component page should render the `NavBar` component and a `UserDetails` component defined in a folder called `users` in your `src/components` folder.

To test this page out, make sure you have the `token` in your `localStorage`.

**Try creating the `UserProfile` and `UserDetails` components on your own. If you need help, please ask a question before looking below.**

```javascript
// src/App.js in your routes
<Route path="/me" component={UserProfile} />
```

```javascript
// src/pages/UserProfile.js
import React from 'react';
import NavBar from '../components/navbar/NavBar.js';
import UserDetails from '../components/users/UserDetails.js';

export default () => {
  return (
    <>
      <NavBar />
      <UserDetails />
    </>
  )
}
```

```javascript
// src/components/users/UserDetails.js
import React from 'react';
import { useQuery } from '@apollo/react-hooks';
import { Link } from 'react-router-dom';
import { CURRENT_USER } from '../../graphql/queries';

export default () => {
  const { data, loading, error } = useQuery(CURRENT_USER);

  if (loading) return <p>Loading</p>;
  if (error) return <p>ERROR</p>;
  if (!data) return <p>Not found</p>;

  return (
    <>
      <h1>Hello {data.me.username}!</h1>
      <h2>List of Borrowed Books</h2>
      <ul>
        {data.me.books && data.me.books.map(book => (
          <li key={book._id}>
            <Link to={`/books/${book._id}`}>
              {book.title}
            </Link>
          </li>
        ))}
      </ul>
    </>
  );
}
```

Now, try refreshing the page when there is no `token` in your `localStorage` (`localStorage.removeItem('token')`). What happens? You should get an error message saying `Cannot read the property 'username' of null`. Try `console.log`ing what `data.me` is. 

`data.me` should be returning `null`. We should not be able to access the `UserProfile` page if there is not valid user logged in. In `Redux` we defined `AuthRoute`'s and `ProtectedRoute`s. Let's create the Apollo Client equivalent.

First, we need to define a query called `IS_LOGGED_IN` that will look into our cache for the `isLoggedIn` boolean for identifying if a user if logged in or not. This is a query that 

Create a folder called `util` in our `src/components` folder with a file called `ProtectedRoute.js`. Remember the `isLoggedIn` boolean that we wrote to our `cache` earlier? We will be using that boolean to either show the component that's passed in, or redirect our user.

```javascript
// src/components/util/ProtectedRoute.js
import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import { useQuery } from '@apollo/react-hooks';
import { IS_LOGGED_IN } from '../../graphql/queries';

export default ({
  component: Component,
  path,
  exact,
  redirectTo
}) => {
  const { data, loading, error } = useQuery(IS_LOGGED_IN);

  if (!redirectTo) redirectTo = "/login";

  if (loading || error || !data) {
    return null;
  } else if (data.isLoggedIn) {
    return <Route path={path} component={Component} exact={exact} />;
  } else {
    return <Redirect to={redirectTo} />;
  }
};
```